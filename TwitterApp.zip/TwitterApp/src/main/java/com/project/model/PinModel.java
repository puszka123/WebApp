package com.project.model;


public class PinModel {
	private String pin = null;
	
	

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }
    
}
